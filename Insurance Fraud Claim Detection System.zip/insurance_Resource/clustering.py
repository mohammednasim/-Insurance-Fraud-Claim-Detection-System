from sklearn.cluster import KMeans
import pandas as pd

def cluster_data(file_path, n_clusters=3):
    data = pd.read_csv(file_path)
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    clusters = kmeans.fit_predict(data)
    return clusters
