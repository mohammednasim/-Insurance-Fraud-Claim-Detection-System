import pandas as pd

def validate_data(file_path):
    required_columns = [
        "months_as_customer", "age", "policy_number", "policy_bind_date",
        "policy_state", "policy_csl", "policy_deductable", "policy_annual_premium",
        "umbrella_limit", "insured_zip", "insured_sex", "insured_education_level",
        "insured_occupation", "insured_hobbies", "insured_relationship",
        "capital-gains", "capital-loss", "incident_date", "incident_type",
        "collision_type", "incident_severity", "authorities_contacted",
        "incident_state", "incident_city", "incident_location",
        "incident_hour_of_the_day", "number_of_vehicles_involved", "property_damage",
        "bodily_injuries", "witnesses", "police_report_available", "total_claim_amount",
        "injury_claim", "property_claim", "vehicle_claim", "auto_make", "auto_model", "auto_year"
    ]

    data = pd.read_csv(file_path)
    if all(column in data.columns for column in required_columns):
        return True
    else:
        return False
