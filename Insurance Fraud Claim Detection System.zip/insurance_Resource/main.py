import pandas as pd
from flask import Flask, render_template, request, redirect, url_for
from model import load_model, load_scaler
import numpy as np
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'datasets/Prediction_Batch_files'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        if file:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(file_path)
            result = perform_prediction(file_path)
            if isinstance(result, str):
                return result
            result_with_index = list(enumerate(result))
            return render_template('result.html', result=result_with_index)
    return render_template('upload.html')

def perform_prediction(file_path):
    model = load_model('models/insurance_fraud_model.pkl')
    scaler = load_scaler('models/trained_scaler.joblib')

    if model is None:
        return "Error: Failed to load the model"
    if scaler is None:
        return "Error: Failed to load the scaler"

    data = pd.read_csv(file_path)

    data['incident_date'] = pd.to_datetime(data['incident_date'])
    data['incident_month'] = data['incident_date'].dt.month
    data['incident_year'] = data['incident_date'].dt.year
    data.drop(['incident_date'], axis=1, inplace=True)

    X = pd.get_dummies(data.drop(['fraud_reported'], axis=1))

    X_scaled = scaler.transform(X)

    predictions = model.predict(X_scaled)

    return predictions

if __name__ == "__main__":
    app.run(debug=True)

