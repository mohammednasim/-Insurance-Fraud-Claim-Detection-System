import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import logging

def save_model(model, file_path):
    try:
        joblib.dump(model, file_path)
        print("Model saved successfully.")
    except Exception as e:
        print(f"Error saving model: {e}")

def save_scaler(scaler, file_path):
    try:
        joblib.dump(scaler, file_path)
        print("Scaler saved successfully.")
    except Exception as e:
        print(f"Error saving scaler: {e}")

def load_model(file_path):
    try:
        model = joblib.load(file_path)
        return model
    except Exception as e:
        print(f"Error loading model: {e}")
        return None

def load_scaler(file_path):
    try:
        scaler = joblib.load(file_path)
        return scaler
    except FileNotFoundError as e:
        logging.error(f"File not found: {e.filename}")
        return None
    except Exception as e:
        logging.error(f"Error loading scaler: {e}")
        return None
