import pandas as pd
import numpy as np
from model import load_model
from preprocessing import preprocess_data


def make_prediction(file_path, scaler, training_columns):
    """
    Make predictions on the data in the given file.

    Args:
    file_path (str): Path to the CSV file containing the data to predict.
    scaler (StandardScaler): Fitted StandardScaler object used for scaling features.
    training_columns (list): List of column names used during model training.

    Returns:
    list: Predictions for each row in the input data.
    """
    try:
        # Load the model
        model = load_model()

        # Read the uploaded CSV file
        data = pd.read_csv(file_path)

        # Preprocess the data
        X_processed = preprocess_data(data, scaler, training_columns)

        # Make prediction
        predictions = model.predict(X_processed)

        # Convert predictions to a list of strings for easier interpretation
        predictions_list = ['Fraud' if pred == 1 else 'Not Fraud' for pred in predictions]

        return predictions_list

    except Exception as e:
        # If any error occurs during the prediction process, return the error message
        return f"An error occurred during prediction: {str(e)}"


def get_feature_importance(file_path, scaler, training_columns):
    """
    Get feature importance for the given data.

    Args:
    file_path (str): Path to the CSV file containing the data.
    scaler (StandardScaler): Fitted StandardScaler object used for scaling features.
    training_columns (list): List of column names used during model training.

    Returns:
    dict: A dictionary of feature names and their importance scores.
    """
    try:
        # Load the model
        model = load_model()

        # Read the uploaded CSV file
        data = pd.read_csv(file_path)

        # Preprocess the data
        X_processed = preprocess_data(data, scaler, training_columns)

        # Get feature importance
        feature_importance = model.feature_importances_

        # Create a dictionary of feature names and their importance scores
        feature_importance_dict = dict(zip(X_processed.columns, feature_importance))

        # Sort the dictionary by importance score in descending order
        sorted_feature_importance = dict(
            sorted(feature_importance_dict.items(), key=lambda item: item[1], reverse=True))

        return sorted_feature_importance

    except Exception as e:
        # If any error occurs during the process, return the error message
        return f"An error occurred while getting feature importance: {str(e)}"
