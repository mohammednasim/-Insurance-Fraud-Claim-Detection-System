import pandas as pd
import numpy as np


def preprocess_data(data, scaler, training_columns):
    """
    Preprocess the data for prediction.

    Args:
    data (pd.DataFrame): The input data to preprocess.
    scaler (StandardScaler): Fitted StandardScaler object used for scaling features.
    training_columns (list): List of column names used during model training.

    Returns:
    pd.DataFrame: Preprocessed data ready for prediction.
    """
    # Convert date columns to datetime if they exist
    if 'incident_date' in data.columns:
        data['incident_date'] = pd.to_datetime(data['incident_date'])
        data['incident_month'] = data['incident_date'].dt.month
        data['incident_year'] = data['incident_date'].dt.year

    if 'policy_bind_date' in data.columns:
        data['policy_bind_date'] = pd.to_datetime(data['policy_bind_date'])

    # Create dummy variables for categorical columns
    categorical_columns = data.select_dtypes(include=['object']).columns
    data_encoded = pd.get_dummies(data, columns=categorical_columns)

    # Ensure all columns from training are present
    for col in training_columns:
        if col not in data_encoded.columns:
            data_encoded[col] = 0

    # Select only the columns that were present during training
    X_processed = data_encoded[training_columns]

    # Select only numeric columns for scaling
    numeric_columns = X_processed.select_dtypes(include=[np.number]).columns
    X_numeric = X_processed[numeric_columns]

    # Scale the numeric data using the provided scaler
    X_scaled = scaler.transform(X_numeric)

    # Create a new DataFrame with scaled numeric data
    X_final = pd.DataFrame(X_scaled, columns=numeric_columns, index=X_processed.index)

    # Add back any non-numeric columns
    for col in X_processed.columns:
        if col not in numeric_columns:
            X_final[col] = X_processed[col]

    return X_final
