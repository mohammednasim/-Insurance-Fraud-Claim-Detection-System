import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from model import save_model, save_scaler
from sklearn.preprocessing import StandardScaler

def train_model():
    data = pd.read_csv('datasets/Training_Batch_Files/fraudDetection_021119920_010222.csv')

    data['incident_date'] = pd.to_datetime(data['incident_date'])
    data['incident_month'] = data['incident_date'].dt.month
    data['incident_year'] = data['incident_date'].dt.year
    data.drop(['incident_date'], axis=1, inplace=True)

    X = pd.get_dummies(data.drop(['fraud_reported'], axis=1))
    y = data['fraud_reported']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train_scaled, y_train)

    save_model(model, 'models/insurance_fraud_model.pkl')
    save_scaler(scaler, 'models/trained_scaler.joblib')
    print("Model training completed and saved successfully!")

if __name__ == "__main__":
    train_model()
