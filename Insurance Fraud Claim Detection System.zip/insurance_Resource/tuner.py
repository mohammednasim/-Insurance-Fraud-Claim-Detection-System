from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
import pandas as pd


def tune_hyperparameters():
    data = pd.read_csv('datasets/Training_Batch_Files/fraudDetection_021119920_010222.csv')
    X = data.drop(['fraud_reported'], axis=1)
    y = data['fraud_reported']

    param_grid = {
        'n_estimators': [50, 100, 200],
        'max_depth': [None, 10, 20, 30],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }

    grid_search = GridSearchCV(estimator=RandomForestClassifier(random_state=42),
                               param_grid=param_grid,
                               cv=5,
                               n_jobs=-1,
                               verbose=2)

    grid_search.fit(X, y)

    print("Best parameters:", grid_search.best_params_)
    print("Best score:", grid_search.best_score_)

    return grid_search.best_estimator_


if __name__ == "__main__":
    best_model = tune_hyperparameters()